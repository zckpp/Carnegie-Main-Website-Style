<?php if ($is_front) { include('header_front.tpl.php'); } else if ((arg(0)=="node")&&(arg(1)==60)) include('header_white.tpl.php');  else { include('header.tpl.php'); } ?>
  <section id="main-wrapper" class="clearfix">
    <div id="main" class="carnegie_container clearfix">
    
      <?php if ($messages): ?>
        <div id="messages"><div class="section clearfix">
          <?php print $messages; ?>
        </div></div> <!-- /.section, /#messages -->
      <?php endif; ?>
  
     <?php if (($page['sidebar_left_first'])||($page['sidebar_left_second'])): ?>
        <?php $donation = false; 
              if ((arg(0)=="node")&&(arg(1)>0)){
                $node = node_load(arg(1)); 
                if ($node->field_donation_content[LANGUAGE_NONE][0]['value']== "Yes") 
                  $donation = true;
              }
?>
        <div id="sidebar-left" class="sidebar sidebar-left <?php if ($donation) print 'donation-page'; ?>">
        <?php if ($page['sidebar_left_first']): ?>
          <div class="sidebar-left-first">
            <div class="mobile-submenu">
              <a href="#"><?php print $title; ?></a>
            </div>
            <?php print render($page['sidebar_left_first']); ?>
          </div>
        <?php endif; ?>
        <?php if ($page['sidebar_left_second']): ?>
          <div class="sidebar-left-second">
            <?php if ($page['sidebar_left_second']) print render($page['sidebar_left_second']); ?>
          </div>
        <?php endif; ?>
        </div> <!-- /.section, /#sidebar-first -->
      <?php endif; ?>
  
      <div id="content" class="column"><div class="section">
        <a id="main-content"></a>

	<!-- Start Donation Form -->
	<div class="giving-form col-xs-12">

		<form id="giftForm" action="/node/1828" method="post">

				<!-- Supported Project -->
				<div id="giftProjects" class="form-group">
					<label for="giftSelection">I Want to Support...</label>
					<select id="giftSelection" name="project" class="form-control input-lg" autofocus>
					<?php 
						$project = array(
              'Carnegie Fund',
              'Department of Embryology',
              'Geophysical Laboratory',
              'Department of Global Ecology',
              'The Carnegie Observatories',
              'Department of Plant Biology',
              'Department of Terrestrial Magnetism',
              'Astronomy Lecture Series',
              'BioEYES',
              'Broad Branch Road Lecture Series',
              'Capital Science Lecture Series',
              'Carnegie Academy for Science Education',
              'Carnegie Astrometric Planet Search',
              'The Carnegie Airborne Observatory',
              'The Giant Magellan Telescope Project',
              'Ocean Acidification Research',
              'Salinity and plants',
	            'Scientific Computing',	
              'Post-Doctoral Research Fund',
              'Visualizing Lipid Metabolism and Signaling',
              'Water Quality',
              'DC STEM Network',
              'The Earthbound Planet Search Program'
						);							
						foreach ($project as $value) {
							echo '<option value="'.$value.'">'.$value.'</option>';
						}
					?>
					</select>
				</div>

				<!-- Recurring Options -->
				<div id="giftProjects" class="form-group">
					<label for="giftRecurrence">Recurrence</label>
					<select id="giftRecurrence" name="gift_recurrence" class="form-control input-lg">
						<option value="One Time">One Time</option>
						<option value="Monthly">Monthly</option>
						<option value="Yearly">Yearly</option>
					</select>
				</div>


				<input class="btn btn-default btn-danger btn-lg" name="Donate Now" type="submit" alt="Donate to Carnegie Science" value="Donate Now">

			</form>
		</div>


        
    </div></div> <!-- /.section, /#content -->

    <?php if ($page['sidebar_right']): ?>
      <div id="sidebar-right" class="sidebar sidebar-right"><div class="section">
        <?php print render($page['sidebar_right']); ?>
      </div></div> <!-- /.section, /#sidebar-second -->
    <?php endif; ?>

  </div></section> <!-- /#main, /#main-wrapper -->

  <?php if ($page['content_bottom']): ?>
    <section id ="content-bottom" class="clearfix">
      <div class="content-bottom">
        <?php print render($page['content_bottom']); ?>
      </div>
    </section>
  <?php endif; ?>
  
<?php include('footer.tpl.php'); ?>


<!-- Set Gift Drop Down Choice -->
<script>

// Read a page's GET URL variables and return them as an associative array.
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

var giftName = getUrlVars()["project"];
var cleanUrl = decodeURIComponent(giftName);
var giftValue = $($("#giftSelection option").val());
var urlLength = cleanUrl.length

jQuery(function( $ ) {
	if(cleanUrl.length < 1){
		$("#giftProjects")[0].selectedIndex = 0;
	} else {
		$("#giftProjects select").val(cleanUrl);
	}
	console.log(urlLength);
});

</script>
